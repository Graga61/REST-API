<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::apiResource('/sleczka/305417/people',\App\Http\Controllers\peoplecontroller::class);
Route::get('/sleczka/305417/people/{people}',[\App\Http\Controllers\peoplecontroller::class,'show']);
Route::post('/sleczka/305417/people/',[\App\Http\Controllers\peoplecontroller::class,'create']);
Route::delete('/sleczka/305417/people/{people}',[\App\Http\Controllers\peoplecontroller::class,'delete']);
Route::put('/sleczka/305417/people/{people}',[\App\Http\Controllers\peoplecontroller::class,'update']);
